package in.festeve.clothing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClothingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClothingApplication.class, args);
	}

}
