package in.festeve.clothing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClothingApplicationTests {

	@Test
	void contextLoads() {
	}

}
